package com.improvelectronics.sync.android.samples;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Rick on 10/25/2014.
 */


public class CurveDisplay extends View {
    Paint paint = new Paint();
    ArrayList<Path> staticHolder;
    ArrayList<Path> dynamicHolder;
    ArrayList<PointF> maxHolder;
    ArrayList<PointF> minHolder;
    ArrayList<Float> DHolder;
    ArrayList<Float> xmomentum;
    ArrayList<Float> ymomentum;
    ArrayList<Float> amomentum;
    ArrayList<Integer> rgb;
    int counter = 0;
    boolean motion = false;

    public CurveDisplay(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(3);
        paint.setStyle(Paint.Style.STROKE);
    }
    public void passPaths(ArrayList<Path> staticCurves,ArrayList<Path> dynamicCurves,ArrayList<PointF> maxCords,ArrayList<PointF> minCords,ArrayList<Float> density){
        staticHolder = staticCurves;
        dynamicHolder = dynamicCurves;
        Random r = new Random();
        xmomentum = new ArrayList<Float>();
        ymomentum = new ArrayList<Float>();
        amomentum = new ArrayList<Float>();
        rgb = new ArrayList<Integer>();
        maxHolder = maxCords;
        minHolder = minCords;
        DHolder = density;

        if(dynamicHolder!=null) {
            for (int i = 0; i < dynamicHolder.size(); i++) {
                double rand = Math.pow((r.nextFloat() - 0.5) * 2.5f,2);
                if(r.nextBoolean()) rand = rand*-1;
                rand -= (DHolder.get(i).floatValue()-150)/43;
                xmomentum.add((new Float(rand)));
                rand = Math.pow((r.nextFloat() - 0.5) * 2.5f,2);
                if(r.nextBoolean()) rand = rand*-1;
                rand *= Math.pow(800-(DHolder.get(i).floatValue()-270)/300,0.1);
                ymomentum.add((new Float(rand)));
                rand = Math.pow((r.nextFloat() - 0.5) * 2.5f,2);
                if(r.nextBoolean()) rand = rand*-1;
                rand *= Math.pow(800-(DHolder.get(i).floatValue()-270)/300,0.1);
                rand *= 100/(maxHolder.get(i).x-minHolder.get(i).x+maxHolder.get(i).y-minHolder.get(i).y);
                amomentum.add((new Float(rand)));
                rgb.add(Color.rgb(r.nextInt(200),r.nextInt(200),r.nextInt(200)));

            }
        }
    }
    public void toggleMotion(boolean m){
        motion = m;
    }

    public void reset(){
        motion = false;
        counter = 0;
    }
    @Override
    public void onDraw(Canvas canvas) {
        canvas.translate(0,1750);
        canvas.rotate(-90);
        //canvas.save();
        canvas.drawColor(Color.WHITE);

        if(staticHolder!=null) {
            for (int i = 0; i < staticHolder.size(); i++) {
                canvas.drawPath(staticHolder.get(i), paint);
            }
        }

        if(dynamicHolder!=null&&staticHolder!=null) {

            if (dynamicHolder != null) {
                for (int i = 0; i < dynamicHolder.size(); i++) {
                    float transx = xmomentum.get(i).floatValue();
                    float transy = ymomentum.get(i).floatValue();
                    float rot = amomentum.get(i).floatValue();
                    transx *= counter;
                    transy *= counter;
                    rot *= counter;

                    canvas.save();
                    canvas.translate((maxHolder.get(i).x+minHolder.get(i).x)/2+transx,(maxHolder.get(i).y+minHolder.get(i).y)/2+transy);
                    canvas.rotate(rot+180);
                    paint.setColor(rgb.get(i).intValue());
                    canvas.drawPath(dynamicHolder.get(i), paint);
                    paint.setColor(Color.BLACK);
                    canvas.restore();
                }
            }

            if(motion) {
                counter++;
            }

        }

    }

}
